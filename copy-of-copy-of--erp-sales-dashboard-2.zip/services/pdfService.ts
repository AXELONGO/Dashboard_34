
import { Lead, HistoryItem, Quote } from "../types";

// Extend Window interface to include jspdf
declare global {
    interface Window {
        jspdf: any;
    }
}

const checkJsPDF = () => {
    if (!window.jspdf) {
        alert("Librería PDF no cargada. Intente recargar la página.");
        return false;
    }
    return true;
};

export const generatePDF = (lead: Lead, history: HistoryItem[]) => {
    if (!checkJsPDF()) return;

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    // --- CONFIGURACIÓN DE COLORES ---
    const primaryColor = [41, 128, 185]; // Azul
    const secondaryColor = [52, 73, 94]; // Gris Oscuro

    // --- ENCABEZADO ---
    // @ts-ignore
    doc.setFillColor(...secondaryColor);
    doc.rect(0, 0, 210, 40, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(22);
    doc.setFont("helvetica", "bold");
    doc.text("Reporte de Cliente", 14, 20);
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(`Generado: ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`, 14, 30);
    
    doc.setFontSize(12);
    doc.text("ERP Vision", 160, 20);

    // --- DATOS DEL CLIENTE ---
    let yPos = 55;
    
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(14);
    doc.setFont("helvetica", "bold");
    doc.text(String(lead.name || "Cliente"), 14, yPos);
    
    // Etiqueta de clase
    const badgeColor = lead.clase === 'A' ? [46, 204, 113] : lead.clase === 'B' ? [52, 152, 219] : [149, 165, 166];
    // @ts-ignore
    doc.setFillColor(...badgeColor);
    
    doc.roundedRect(160, yPos - 6, 30, 8, 2, 2, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(10);
    doc.text(`Clase ${lead.clase || 'C'}`, 165, yPos);

    yPos += 10;
    
    // Detalles en Grid
    doc.setTextColor(80, 80, 80);
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    
    doc.text("Dirección:", 14, yPos);
    doc.setFont("helvetica", "normal");
    doc.text(String(lead.address || "N/A"), 40, yPos);
    
    yPos += 7;
    doc.setFont("helvetica", "bold");
    doc.text("Teléfono:", 14, yPos);
    doc.setFont("helvetica", "normal");
    doc.text(String(lead.phone || "N/A"), 40, yPos);
    
    yPos += 7;
    doc.setFont("helvetica", "bold");
    doc.text("Web:", 14, yPos);
    doc.setFont("helvetica", "normal");
    doc.text(String(lead.website || "N/A"), 40, yPos);
    
    yPos += 7;
    doc.setFont("helvetica", "bold");
    doc.text("Asesor:", 14, yPos);
    doc.setFont("helvetica", "normal");
    doc.text(String(lead.agent || "No asignado"), 40, yPos);

    // --- TABLA DE HISTORIAL ---
    yPos += 15;
    
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(0, 0, 0);
    doc.text("Historial de Seguimiento", 14, yPos);
    
    yPos += 5;

    const tableColumn = ["Fecha", "Tipo", "Asesor", "Detalle"];
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const tableRows: any[] = [];

    history.forEach(item => {
        const rowData = [
            String(item.timestamp || ""),
            String(item.title || ""), 
            String(item.user.name || ""),
            String(item.description || "")
        ];
        tableRows.push(rowData);
    });

    (doc as any).autoTable({
        head: [tableColumn],
        body: tableRows,
        startY: yPos,
        theme: 'grid',
        headStyles: { fillColor: primaryColor, textColor: 255, fontStyle: 'bold' },
        styles: { fontSize: 9, cellPadding: 3 },
        columnStyles: {
            0: { cellWidth: 30 }, // Fecha
            1: { cellWidth: 25 }, // Tipo
            2: { cellWidth: 25 }, // Asesor
            3: { cellWidth: 'auto' } // Detalle
        },
        alternateRowStyles: { fillColor: [245, 245, 245] }
    });

    const safeName = lead.name ? lead.name.replace(/[^a-z0-9]/gi, '_').toLowerCase() : 'reporte';
    const fileName = `Reporte_${safeName}.pdf`;
    doc.save(fileName);
};

export const generateQuotePDF = (quote: Quote) => {
    if (!checkJsPDF()) return;

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Colores corporativos
    const headerBg = [15, 23, 42]; // Slate 900
    const accentColor = [59, 130, 246]; // Blue 500

    // --- ENCABEZADO ---
    // Fondo oscuro superior
    // @ts-ignore
    doc.setFillColor(...headerBg);
    doc.rect(0, 0, 210, 45, 'F');

    // Título / Logo
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(24);
    doc.setFont("helvetica", "bold");
    doc.text("ERP Vision", 14, 20);
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text("Soluciones Tecnológicas Integrales", 14, 26);
    doc.text("www.erpvision.com", 14, 31);

    // Datos de Cotización (Derecha)
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.text("COTIZACIÓN", 195, 20, { align: 'right' });
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(`Folio: ${quote.folio}`, 195, 28, { align: 'right' });
    doc.text(`Fecha: ${quote.date}`, 195, 34, { align: 'right' });

    // --- INFORMACIÓN DEL CLIENTE ---
    let yPos = 60;
    
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text("Datos del Cliente:", 14, yPos);
    
    yPos += 8;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.text(`Empresa: ${quote.company}`, 14, yPos);
    doc.text(`Contacto: ${quote.contact}`, 110, yPos);
    
    yPos += 6;
    doc.text(`Teléfono: ${quote.phone}`, 14, yPos);
    doc.text(`Correo: ${quote.email}`, 110, yPos);

    // --- TABLA DE PRODUCTOS ---
    yPos += 15;

    const tableColumn = ["Cant", "Descripción", "P. Unitario", "Importe"];
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const tableRows: any[] = [];

    quote.items.forEach(item => {
        const rowData = [
            item.quantity.toString(),
            item.description,
            `$${item.unitPrice.toFixed(2)}`,
            `$${item.amount.toFixed(2)}`
        ];
        tableRows.push(rowData);
    });

    (doc as any).autoTable({
        head: [tableColumn],
        body: tableRows,
        startY: yPos,
        theme: 'striped',
        headStyles: { fillColor: headerBg, textColor: 255, fontStyle: 'bold' },
        styles: { fontSize: 9, cellPadding: 3 },
        columnStyles: {
            0: { cellWidth: 20, halign: 'center' },
            1: { cellWidth: 'auto' },
            2: { cellWidth: 30, halign: 'right' },
            3: { cellWidth: 30, halign: 'right' }
        },
        foot: [
            ['', '', 'Subtotal:', `$${quote.subtotal.toFixed(2)}`],
            ['', '', 'IVA (16%):', `$${quote.iva.toFixed(2)}`],
            ['', '', 'TOTAL:', `$${quote.total.toFixed(2)}`]
        ],
        footStyles: { fillColor: [255, 255, 255], textColor: [0, 0, 0], fontStyle: 'bold', halign: 'right' }
    });

    // Obtener posición final de la tabla
    const finalY = (doc as any).lastAutoTable.finalY || yPos + 40;
    
    // --- NOTAS ---
    if (quote.notes) {
        let noteY = finalY + 10;
        doc.setFontSize(10);
        doc.setFont("helvetica", "bold");
        doc.text("Notas:", 14, noteY);
        
        doc.setFont("helvetica", "normal");
        doc.setTextColor(80, 80, 80);
        const splitNotes = doc.splitTextToSize(quote.notes, 180);
        doc.text(splitNotes, 14, noteY + 6);
    }

    // --- PIE DE PÁGINA ---
    const pageHeight = doc.internal.pageSize.height;
    
    // @ts-ignore
    doc.setFillColor(...headerBg);
    doc.rect(0, pageHeight - 20, 210, 20, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8);
    doc.text("ERP Vision - Software de Gestión Empresarial", 105, pageHeight - 12, { align: 'center' });
    doc.text("Calle Tecnológica 123, Ciudad de México | Tel: 55-1234-5678", 105, pageHeight - 8, { align: 'center' });

    // Guardar
    doc.save(`Cotizacion_${quote.folio}.pdf`);
}
