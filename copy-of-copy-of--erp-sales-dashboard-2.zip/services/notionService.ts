
import { Lead, HistoryItem } from "../types";

// ⚠️ ADVERTENCIA DE SEGURIDAD ⚠️
// Estás usando la API Key en el frontend. Esto expone tu clave a cualquiera que inspeccione el código.
// Para producción, DEBES mover esto a un backend (Node.js, Vercel, etc).
const NOTION_API_KEY = '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';
const NOTION_DATABASE_ID = '2c154639-4c41-80c2-9fec-f7bd939eaf3c'; 
const NOTION_HISTORY_DB_ID = '2c154639-4c41-80da-8799-ee2ff8ffa0ff'; 
const CORS_PROXY = "https://corsproxy.io/?";

// --- HELPERS ---

const fetchWithProxy = async (url: string, options: RequestInit) => {
    const proxyUrl = `${CORS_PROXY}${encodeURIComponent(url)}`;
    try {
        const response = await fetch(proxyUrl, options);
        return response;
    } catch (error) {
        console.error("🔥 Error de red (Posible fallo de CORS Proxy):", error);
        throw error;
    }
};

// --- SCHEMA DETECTION ---
// Esta función averigua cómo se llaman realmente tus columnas
const detectHistorySchema = async () => {
    const url = `https://api.notion.com/v1/databases/${NOTION_HISTORY_DB_ID}`;
    try {
        const response = await fetchWithProxy(url, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${NOTION_API_KEY}`,
                'Notion-Version': '2022-06-28',
            }
        });
        const db = await response.json();
        const props = db.properties || {};
        
        // Buscar nombres reales
        const relationKey = Object.keys(props).find(k => props[k].type === 'relation') || 'Cliente';
        const titleKey = Object.keys(props).find(k => props[k].type === 'title') || 'Asesor';
        const contactKey = Object.keys(props).find(k => k.toLowerCase().includes('contacto') || k.toLowerCase().includes('prospeccion')) || 'Contacto';
        
        return { relationKey, titleKey, contactKey };
    } catch (e) {
        console.warn("No se pudo detectar esquema, usando defaults:", e);
        return { relationKey: 'Cliente', titleKey: 'Asesor', contactKey: 'Contacto' };
    }
}

// --- LEADS ---

export const getLeadsFromNotion = async (): Promise<Lead[]> => {
  if (!NOTION_DATABASE_ID) return [];

  const url = `https://api.notion.com/v1/databases/${NOTION_DATABASE_ID}/query`;
  
  let allResults: any[] = [];
  let hasMore = true;
  let nextCursor: string | undefined = undefined;

  try {
    while (hasMore) {
        const response = await fetchWithProxy(url, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${NOTION_API_KEY}`,
            'Content-Type': 'application/json',
            'Notion-Version': '2022-06-28',
          },
          body: JSON.stringify({
            page_size: 100,
            start_cursor: nextCursor
          })
        });

        if (!response.ok) {
           const errText = await response.text();
           console.error(`❌ Error Notion Leads: ${response.status}`, errText);
           throw new Error(errText);
        }

        const data = await response.json();
        allResults = [...allResults, ...data.results];
        hasMore = data.has_more;
        nextCursor = data.next_cursor || undefined;
    }
    
    // Mapeo Robusto
    return allResults.map((page: any) => {
      const props = page.properties;
      const keys = Object.keys(props);
      
      const titleKey = keys.find(key => props[key].type === 'title') || 'Name';
      const name = props[titleKey]?.title?.[0]?.plain_text || 'Sin Nombre';

      const addressKey = keys.find(k => /address|direcci|ubicaci/i.test(k));
      const address = addressKey && props[addressKey]?.rich_text?.[0]?.plain_text || 'Dirección no especificada';

      const phoneKey = keys.find(k => /phone|tel/i.test(k));
      const phone = props[phoneKey]?.phone_number || props[phoneKey]?.rich_text?.[0]?.plain_text || '';

      const webKey = keys.find(k => /web|url/i.test(k));
      const website = props[webKey]?.url || '';

      const classKey = keys.find(k => /clase|class/i.test(k));
      let clase: 'A'|'B'|'C' = 'C';
      if (classKey) {
          const cProp = props[classKey];
          if (cProp.type === 'select') clase = cProp.select?.name as any || 'C';
          else if (cProp.type === 'rich_text') clase = cProp.rich_text?.[0]?.plain_text as any || 'C';
      }

      const agentKey = keys.find(k => /responsable|agent/i.test(k));
      const agent = props[agentKey]?.select?.name || 'Sin Asignar';

      // Guardamos metadatos para actualizaciones futuras
      const notionData = {
          claseColName: classKey || 'Clase',
          claseColType: props[classKey]?.type || 'select'
      };

      return {
        id: page.id,
        name,
        address,
        phone,
        website,
        category: 'Otros', // Simplificado
        clase,
        agent,
        isSelected: false,
        isSynced: true,
        notionData
      };
    });

  } catch (error) {
    console.error("Error crítico obteniendo leads:", error);
    return [];
  }
};

export const updateLeadClass = async (leadId: string, newClass: string, notionData?: any): Promise<boolean> => {
    const url = `https://api.notion.com/v1/pages/${leadId}`;
    const propName = notionData?.claseColName || 'Clase';
    const propType = notionData?.claseColType || 'select';

    const properties: any = {};
    if (propType === 'rich_text') {
        properties[propName] = { rich_text: [{ text: { content: newClass } }] };
    } else {
        properties[propName] = { select: { name: newClass } };
    }

    try {
        const response = await fetchWithProxy(url, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${NOTION_API_KEY}`,
                'Content-Type': 'application/json',
                'Notion-Version': '2022-06-28',
            },
            body: JSON.stringify({ properties })
        });
        
        if (!response.ok) {
            console.error("❌ Fallo actualizando clase:", await response.text());
            return false;
        }
        return true;
    } catch (e) { return false; }
}

export const syncLeadToNotion = async (lead: Lead): Promise<boolean> => {
    // Implementación simplificada
    return true; 
};

// --- HISTORIAL (LA PARTE CRÍTICA) ---

export const getHistoryFromNotionDatabase = async (leadId?: string): Promise<HistoryItem[]> => {
    if (!NOTION_HISTORY_DB_ID) return [];

    const url = `https://api.notion.com/v1/databases/${NOTION_HISTORY_DB_ID}/query`;
    
    // Filtro en memoria
    const payload = {
        sorts: [{ timestamp: "created_time", direction: "descending" }],
        page_size: 100
    };

    try {
        const response = await fetchWithProxy(url, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${NOTION_API_KEY}`,
                'Content-Type': 'application/json',
                'Notion-Version': '2022-06-28',
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) throw new Error(await response.text());

        const data = await response.json();
        
        let items = data.results.map((page: any) => {
            const props = page.properties;
            const keys = Object.keys(props);

            // 1. TÍTULO (Asesor)
            const titleKey = keys.find(k => props[k].type === 'title') || 'Asesor';
            const agentName = props[titleKey]?.title?.[0]?.plain_text || 'Sistema';

            // 2. TIPO / CONTACTO
            const typeKey = keys.find(k => /contacto|prospeccion/i.test(k)) || 'Contacto';
            const typeProp = props[typeKey];
            let title = 'Nota';
            if (typeProp?.rich_text?.length > 0) title = typeProp.rich_text[0].plain_text;
            else if (typeProp?.select) title = typeProp.select.name;

            // 3. DESCRIPCIÓN
            const descKey = keys.find(k => /comentario|detalle|descri/i.test(k)) || 'Comentario';
            const description = props[descKey]?.rich_text?.[0]?.plain_text || '';

            // 4. RELACIÓN CLIENTE (EXTRACCIÓN BLINDADA)
            // Buscamos CUALQUIER propiedad que sea de tipo 'relation' y tenga datos
            let clientId: string | undefined = undefined;
            
            // Primero intentamos buscar por nombre "Cliente" o "Empresa"
            const explicitClientKey = keys.find(k => /cliente|empresa|lead/i.test(k) && props[k].type === 'relation');
            
            if (explicitClientKey && props[explicitClientKey].relation.length > 0) {
                clientId = props[explicitClientKey].relation[0].id;
            } else {
                // Fallback: Buscar CUALQUIER relación que tenga un ID
                for (const key of keys) {
                    if (props[key].type === 'relation' && props[key].relation.length > 0) {
                        clientId = props[key].relation[0].id;
                        break; // Tomamos el primero que encontremos
                    }
                }
            }

            // 5. FECHA
            const dateKey = keys.find(k => /fecha|date/i.test(k));
            const dateStr = props[dateKey]?.date?.start || page.created_time;
            const timestamp = new Date(dateStr).toLocaleString([], {month:'short', day:'numeric', hour: '2-digit', minute:'2-digit'});

            // Determinar icono
            let type: 'call' | 'email' | 'note' = 'note';
            const tLower = title.toLowerCase();
            if (tLower.includes('llamada') || tLower.includes('tel')) type = 'call';
            if (tLower.includes('mail') || tLower.includes('correo') || tLower.includes('what')) type = 'email';

            return {
                id: page.id,
                type,
                title,
                timestamp,
                description,
                user: { name: agentName, avatarUrl: '' },
                clientId, 
                isSynced: true
            };
        });

        if (leadId) {
            items = items.filter((i: HistoryItem) => i.clientId === leadId);
        }

        return items;

    } catch (e) {
        console.error("❌ Error leyendo historial:", e);
        return [];
    }
};

// --- FUNCIÓN DE GUARDADO ---

export const addHistoryToNotionDatabase = async (leadId: string, text: string, agent: string, interactionType: string): Promise<HistoryItem | null> => {
    if (!NOTION_HISTORY_DB_ID) {
        console.error("❌ Error: Falta ID de la base de datos de Historial");
        return null;
    }

    if (leadId.includes('gen-') || leadId.includes('temp-')) {
        console.warn("⚠️ Advertencia: Intentando guardar historial en un Lead no sincronizado.");
        return null; 
    }

    // 1. DETECTAR ESQUEMA REAL
    const schema = await detectHistorySchema();
    console.log("Schema detectado:", schema);

    const url = `https://api.notion.com/v1/pages`;
    
    // 2. CONSTRUIR PAYLOAD DINÁMICO
    const properties: any = {};
    
    // Título (Asesor)
    properties[schema.titleKey] = { title: [{ type: "text", text: { content: agent } }] };
    
    // Relación (Cliente) - USANDO EL NOMBRE DETECTADO
    properties[schema.relationKey] = { relation: [{ id: leadId }] };
    
    // Contacto
    properties[schema.contactKey] = { rich_text: [{ type: "text", text: { content: interactionType } }] };
    
    // Comentario (Fijo o detectado si quisieras)
    properties["Comentario"] = { rich_text: [{ type: "text", text: { content: text } }] };
    
    // Fecha
    properties["Fecha"] = { date: { start: new Date().toISOString() } };

    const payload = {
        parent: { database_id: NOTION_HISTORY_DB_ID },
        properties: properties
    };

    try {
        const response = await fetchWithProxy(url, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${NOTION_API_KEY}`,
                'Content-Type': 'application/json',
                'Notion-Version': '2022-06-28'
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const errorBody = await response.text();
            console.error("🔥 FALLO CRÍTICO AL GUARDAR EN NOTION:", response.status);
            console.error("Detalle del error:", errorBody);
            return null;
        }

        const data = await response.json();
        console.log("✅ Historial guardado correctamente en Notion:", data.id);
        
        return {
            id: data.id,
            type: interactionType.toLowerCase().includes('mail') || interactionType.toLowerCase().includes('what') ? 'email' : 'note',
            title: interactionType,
            description: text,
            timestamp: new Date().toLocaleString([], {month:'short', day:'numeric', hour: '2-digit', minute:'2-digit'}),
            user: { name: agent, avatarUrl: '' },
            clientId: leadId,
            isSynced: true
        };

    } catch (error) {
        console.error("❌ Error de red al conectar con Notion:", error);
        return null;
    }
};
