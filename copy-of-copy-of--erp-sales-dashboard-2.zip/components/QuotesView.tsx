
import React, { useState, useEffect } from 'react';
import { Quote, QuoteItem } from '../types';
import { generateQuotePDF } from '../services/pdfService';

const MOCK_HISTORY: Quote[] = [
    { 
        id: '1', 
        folio: 'QT-2023-001', 
        date: '2023-10-24', 
        company: 'Tech Solutions S.A.', 
        contact: 'Carlos Ruiz',
        phone: '5512345678',
        email: 'carlos@tech.com',
        items: [],
        subtotal: 10732.76, 
        iva: 1717.24, 
        total: 12450.00, 
        notes: 'Pago a 30 días',
        agent: 'Asesor 1' 
    },
];

const QuotesView: React.FC = () => {
  // Form State
  const [company, setCompany] = useState('');
  const [contact, setContact] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [agent, setAgent] = useState('Asesor 1');
  const [notes, setNotes] = useState('');
  const [items, setItems] = useState<QuoteItem[]>([
      { id: '1', quantity: 1, description: '', unitPrice: 0, amount: 0 }
  ]);

  // Totals State
  const [subtotal, setSubtotal] = useState(0);
  const [iva, setIva] = useState(0);
  const [total, setTotal] = useState(0);

  // History State
  const [history, setHistory] = useState<Quote[]>(MOCK_HISTORY);
  const [isProcessing, setIsProcessing] = useState(false);

  // Calculate totals whenever items change
  useEffect(() => {
      const sub = items.reduce((sum, item) => sum + item.amount, 0);
      const tax = sub * 0.16;
      setSubtotal(sub);
      setIva(tax);
      setTotal(sub + tax);
  }, [items]);

  const handleItemChange = (id: string, field: keyof QuoteItem, value: any) => {
      setItems(prev => prev.map(item => {
          if (item.id === id) {
              const updated = { ...item, [field]: value };
              // Recalculate amount
              if (field === 'quantity' || field === 'unitPrice') {
                  const qty = field === 'quantity' ? value : item.quantity;
                  const price = field === 'unitPrice' ? value : item.unitPrice;
                  updated.amount = Number(qty) * Number(price);
              }
              return updated;
          }
          return item;
      }));
  };

  const addItem = () => {
      const newItem: QuoteItem = {
          id: Date.now().toString(),
          quantity: 1,
          description: '',
          unitPrice: 0,
          amount: 0
      };
      setItems([...items, newItem]);
  };

  const removeItem = (id: string) => {
      if (items.length > 1) {
          setItems(items.filter(i => i.id !== id));
      }
  };

  const createQuoteObject = (): Quote => {
      return {
          id: Date.now().toString(),
          folio: `QT-${new Date().getFullYear()}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
          date: new Date().toLocaleDateString('es-MX'),
          company,
          contact,
          phone,
          email,
          items,
          subtotal,
          iva,
          total,
          notes,
          agent
      };
  };

  const handleGeneratePDF = () => {
      if (!company) return alert("Ingrese el nombre de la empresa");
      setIsProcessing(true);
      
      try {
          const newQuote = createQuoteObject();
          
          // Simular llamada a Endpoint como solicitado
          console.log(`POST /api/cotizacion/pdf`, newQuote);
    
          // Simular guardado local para el historial
          setHistory([newQuote, ...history]);
          
          // Generar PDF usando el servicio
          generateQuotePDF(newQuote);
      } catch (error) {
          console.error("Error generando PDF:", error);
          alert("Hubo un error al generar el PDF.");
      } finally {
          setIsProcessing(false);
      }
  };

  const handleSendWhatsApp = () => {
      if (!phone) return alert("Ingrese un número de teléfono");
      
      const newQuote = createQuoteObject();
      const message = `Hola ${contact}, te comparto la cotización ${newQuote.folio} de ERP Vision.\n\nTotal: $${total.toFixed(2)}\n\nQuedo atento a tus comentarios.`;
      const encodedMessage = encodeURIComponent(message);
      
      window.open(`https://wa.me/${phone.replace(/[^0-9]/g, '')}?text=${encodedMessage}`, '_blank');
  };

  // Styles for light inputs on dark background - Texto negro, fondo blanco
  const inputClass = "w-full rounded-lg py-2 px-3 text-sm bg-white text-black border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none shadow-sm transition-all placeholder-gray-400 font-medium";
  const labelClass = "text-xs font-bold text-gray-300 uppercase tracking-wide mb-1 block";

  return (
    <div className="flex-1 overflow-y-auto px-4 md:px-8 py-6 space-y-8 animate-in fade-in duration-500 scroll-smooth pb-20">
      
      {/* SECTION: NEW QUOTE FORM */}
      <section className="fade-in-up" style={{animationDelay: '0.1s'}}>
        <div className="flex items-center gap-3 mb-5">
            <div className="size-8 rounded-lg bg-blue-500/20 flex items-center justify-center border border-blue-500/30">
                <span className="material-symbols-outlined text-blue-400 text-[20px]">add_circle</span>
            </div>
            <h2 className="text-xl font-bold text-white text-glow tracking-tight">Nueva Cotización</h2>
        </div>
        
        <div className="glass-panel p-6 md:p-8 rounded-2xl relative overflow-hidden">
            {/* Header Data */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <div className="space-y-4">
                    <h3 className="text-white font-bold border-b border-white/10 pb-2">Datos del Cliente</h3>
                    <div className="grid grid-cols-1 gap-4">
                        <div>
                            <label className={labelClass}>Empresa</label>
                            <input 
                                type="text" placeholder="Nombre de la empresa" 
                                className={inputClass}
                                value={company} onChange={e => setCompany(e.target.value)}
                            />
                        </div>
                        <div>
                            <label className={labelClass}>Contacto</label>
                            <input 
                                type="text" placeholder="Nombre del contacto" 
                                className={inputClass}
                                value={contact} onChange={e => setContact(e.target.value)}
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className={labelClass}>Teléfono</label>
                                <input 
                                    type="text" placeholder="55 1234 5678" 
                                    className={inputClass}
                                    value={phone} onChange={e => setPhone(e.target.value)}
                                />
                            </div>
                            <div>
                                <label className={labelClass}>Correo</label>
                                <input 
                                    type="email" placeholder="contacto@empresa.com" 
                                    className={inputClass}
                                    value={email} onChange={e => setEmail(e.target.value)}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                
                <div className="space-y-4">
                    <h3 className="text-white font-bold border-b border-white/10 pb-2">Detalles Generales</h3>
                    <div className="grid grid-cols-1 gap-4">
                        <div className="grid grid-cols-2 gap-4">
                             <div>
                                <label className={labelClass}>Fecha</label>
                                <input type="text" disabled value={new Date().toLocaleDateString()} className={`${inputClass} bg-gray-200 text-gray-600 cursor-not-allowed`} />
                             </div>
                             <div>
                                <label className={labelClass}>Folio (Auto)</label>
                                <input type="text" disabled value="###" className={`${inputClass} bg-gray-200 text-gray-600 cursor-not-allowed`} />
                             </div>
                        </div>
                        <div>
                            <label className={labelClass}>Representante</label>
                            <select 
                                className={inputClass}
                                value={agent} onChange={e => setAgent(e.target.value)}
                            >
                                <option>Asesor 1</option>
                                <option>Asesor 2</option>
                                <option>Asesor 3</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            {/* Products Table */}
            <div className="mb-6 overflow-x-auto bg-white/5 rounded-xl p-1 border border-white/10">
                <table className="w-full text-left border-collapse">
                    <thead>
                        <tr className="text-xs text-gray-400 uppercase border-b border-white/10">
                            <th className="py-3 px-3 w-20 text-center">Cant</th>
                            <th className="py-3 px-3">Descripción</th>
                            <th className="py-3 px-3 w-36 text-right">P. Unitario</th>
                            <th className="py-3 px-3 w-36 text-right">Importe</th>
                            <th className="py-3 px-3 w-12"></th>
                        </tr>
                    </thead>
                    <tbody className="text-sm">
                        {items.map((item) => (
                            <tr key={item.id} className="border-b border-white/5 group hover:bg-white/5 transition-colors">
                                <td className="py-2 px-2">
                                    <input 
                                        type="number" min="1"
                                        className={`${inputClass} text-center font-bold`}
                                        value={item.quantity}
                                        onChange={e => handleItemChange(item.id, 'quantity', parseInt(e.target.value) || 0)}
                                    />
                                </td>
                                <td className="py-2 px-2">
                                    <input 
                                        type="text" 
                                        className={inputClass}
                                        placeholder="Descripción"
                                        value={item.description}
                                        onChange={e => handleItemChange(item.id, 'description', e.target.value)}
                                    />
                                </td>
                                <td className="py-2 px-2">
                                    <div className="relative">
                                        <span className="absolute left-3 top-2.5 text-gray-500 text-xs">$</span>
                                        <input 
                                            type="number" min="0" step="0.01"
                                            className={`${inputClass} text-right pl-6`}
                                            value={item.unitPrice}
                                            onChange={e => handleItemChange(item.id, 'unitPrice', parseFloat(e.target.value) || 0)}
                                        />
                                    </div>
                                </td>
                                <td className="py-2 px-3 text-right text-white font-mono font-bold">
                                    ${item.amount.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                                </td>
                                <td className="py-2 px-2 text-center">
                                    <button 
                                        onClick={() => removeItem(item.id)}
                                        className="text-gray-500 hover:text-red-400 transition-colors p-2 rounded hover:bg-white/10"
                                        title="Eliminar fila"
                                    >
                                        <span className="material-symbols-outlined text-[20px]">delete</span>
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                <button 
                    onClick={addItem}
                    className="m-2 text-xs flex items-center gap-1 text-blue-400 hover:text-blue-300 transition-colors font-bold uppercase tracking-wide px-3 py-2 rounded hover:bg-blue-500/10"
                >
                    <span className="material-symbols-outlined text-[18px]">add</span> Agregar Producto
                </button>
            </div>

            {/* Totals & Notes */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <div>
                    <label className={labelClass}>Notas</label>
                    <textarea 
                        className={`${inputClass} h-32 resize-none`} 
                        placeholder="Condiciones de pago, tiempo de entrega, datos bancarios..."
                        value={notes}
                        onChange={e => setNotes(e.target.value)}
                    ></textarea>
                </div>
                <div className="space-y-4 bg-white/5 p-6 rounded-xl border border-white/5">
                    <div className="flex justify-between text-gray-300 text-sm">
                        <span>Subtotal</span>
                        <span className="font-mono text-white">${subtotal.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                    </div>
                    <div className="flex justify-between text-gray-300 text-sm">
                        <span>IVA (16%)</span>
                        <span className="font-mono text-white">${iva.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                    </div>
                    <div className="flex justify-between text-white text-xl font-bold border-t border-white/10 pt-4 mt-2">
                        <span>Total</span>
                        <span className="font-mono text-blue-400">${total.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                    </div>
                </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-4 border-t border-white/10 pt-6">
                <button 
                    onClick={handleSendWhatsApp}
                    className="bg-[#25D366] hover:bg-[#20bd5a] text-white font-bold py-3 px-6 rounded-lg flex items-center gap-2 transition-all shadow-lg active:scale-95"
                >
                    <span className="material-symbols-outlined text-[20px]">chat</span>
                    WhatsApp
                </button>
                <button 
                    onClick={handleGeneratePDF}
                    disabled={isProcessing}
                    className="bg-btn-primary text-black font-bold py-3 px-6 rounded-lg flex items-center gap-2 transition-all shadow-lg hover:shadow-white/10 active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                    {isProcessing ? (
                        <span className="material-symbols-outlined text-[20px] animate-spin">progress_activity</span>
                    ) : (
                        <span className="material-symbols-outlined text-[20px]">picture_as_pdf</span>
                    )}
                    Generar PDF
                </button>
            </div>
        </div>
      </section>

      {/* SECTION: HISTORY TABLE */}
      <section className="fade-in-up" style={{animationDelay: '0.2s'}}>
        <h2 className="text-xl font-bold text-white text-glow tracking-tight mb-4">Historial de Cotizaciones</h2>
        <div className="glass-panel rounded-2xl overflow-hidden shadow-2xl">
            <div className="grid grid-cols-12 gap-4 p-4 border-b border-white/10 bg-white/[0.03] text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                <div className="col-span-2">Folio</div>
                <div className="col-span-3">Empresa</div>
                <div className="col-span-2">Fecha</div>
                <div className="col-span-2 text-right">Total</div>
                <div className="col-span-2">Agente</div>
                <div className="col-span-1 text-center">Acción</div>
            </div>
            <div className="divide-y divide-white/5">
                {history.map((q) => (
                    <div key={q.id} className="grid grid-cols-12 gap-4 p-4 items-center hover:bg-white/[0.05] transition-colors">
                        <div className="col-span-2 text-blue-400 font-mono text-xs">{q.folio}</div>
                        <div className="col-span-3 text-white text-sm truncate" title={q.company}>{q.company}</div>
                        <div className="col-span-2 text-gray-400 text-xs">{q.date}</div>
                        <div className="col-span-2 text-right text-white font-mono text-sm">${q.total.toLocaleString()}</div>
                        <div className="col-span-2 text-gray-400 text-xs">{q.agent}</div>
                        <div className="col-span-1 text-center">
                            <button 
                                onClick={() => generateQuotePDF(q)}
                                className="text-gray-400 hover:text-white transition-colors p-2 rounded hover:bg-white/10"
                                title="Descargar PDF"
                            >
                                <span className="material-symbols-outlined text-[20px]">download</span>
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </section>
    </div>
  );
};

export default QuotesView;
